const net = require('net');
const readline = require('readline');

// Create a readline interface for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Ask the user for a username
rl.question('Enter a username to join the chat: ', username => {
    // Connect to the server once we have the username
    const socket = net.connect({ port: 1235 }, () => {
        console.log('Connected to chat server.');
        // Send the username as the first piece of data
        socket.write(username + "\n");
    });

    // Handle user input from the command line
    rl.on('line', line => {
        if (line === '/quit') {
            // Properly close the connection on quit command
            socket.end(`${username} has left the chat.\n`);
        } else if (line.startsWith('/pm')) {
            // Handle the private message command
            // The message format sent to the server remains the same
            // But this indicates to the server it's a private message
            socket.write(line + "\n");
        } else {
            // For normal messages, prepend the username
            // No change needed here since the server now expects the username in all messages
            socket.write(`${username}: ${line}\n`);
        }
    });

    // Handle incoming messages from the server
    socket.on('data', data => {
        // Display the incoming message
        // The coloring remains for visibility
        console.log('\x1b[33m%s\x1b[0m', data.toString().trim());
    });

    // Handle disconnection from the server
    socket.on('end', () => {
        console.log('Disconnected from server.');
        rl.close();
        process.exit();
    });

    // Handle a timeout if set (after 'quit' command is sent)
    socket.on('timeout', () => {
        socket.end();
    });

    // Handle errors such as the server shutting down
    socket.on('error', error => {
        console.error('Connection error:', error.message);
        rl.close();
        process.exit();
    });
});
