const net = require('net');

let clients = [];
let coordinator = null;

function broadcast(message, sender) {
    clients.forEach(client => {
        if (client !== sender) {
            client.socket.write(message);
        }
    });
}

function electCoordinator() {
    if (clients.length > 0) {
        coordinator = clients[0];
        coordinator.socket.write('You are the new coordinator.\n');
        broadcast(`${coordinator.username} is the new coordinator.\n`, coordinator);
        console.log('A new coordinator has been elected.');
    } else {
        coordinator = null;
        console.log('No clients connected, coordinator election postponed.');
    }
}

function sendPrivateMessage(sender, recipientUsername, message) {
    const recipient = clients.find(client => client.username === recipientUsername);
    if (recipient) {
        recipient.socket.write(`[PM from ${sender.username}]: ${message}\n`);
    } else {
        sender.socket.write('User not found.\n');
    }
}

const server = net.createServer(clientSocket => {
    let currentClient = { socket: clientSocket, username: null };

    clientSocket.on('data', data => {
        const message = data.toString().trim();
        if (currentClient.username === null) {
            // First message from the client should be their username
            currentClient.username = message;
            clients.push(currentClient);
            console.log(`A new client has connected: ${message}`);

            // Elect coordinator if none exists
            if (!coordinator) {
                coordinator = currentClient;
                console.log('A new coordinator has been elected.');
                coordinator.socket.write('You are the coordinator.\n');
            } else {
                clientSocket.write(`${coordinator.username} is the coordinator.\n`);
            }
            return;
        }

        console.log(`Received message: ${message}`);
        if (message.startsWith('/pm')) {
            const parts = message.split(' ');
            if (parts.length >= 3) {
                const recipientUsername = parts[1];
                const privateMessage = parts.slice(2).join(' ');
                sendPrivateMessage(currentClient, recipientUsername, privateMessage);
            }
        } else {
            broadcast(message, currentClient);
        }
    });

    clientSocket.on('end', () => {
        console.log(`${currentClient.username} has disconnected.`);
        clients = clients.filter(client => client !== currentClient);
        if (currentClient === coordinator) {
            electCoordinator();
        }
    });

    clientSocket.on('error', error => {
        console.error(`Connection error: ${error}`);
        clientSocket.end(); // Properly close the socket
    });
});

server.listen(1235, () => {
    console.log('Server listening on port 1235');
});
