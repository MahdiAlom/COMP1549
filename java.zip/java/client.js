const net = require('net');
const readline = require('readline');

// Create a readline interface for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Ask the user for a username
rl.question('Enter a username to join the chat: ', username => {
    // Connect to the server once we have the username
    const socket = net.connect({ port: 1235 }, () => {
        console.log('Connected to chat server.');
        // Send the username as the first piece of data
        socket.write(username);
    });

    // Handle user input from the command line
    rl.on('line', line => {
        if (line === '/quit') {
            // Properly close the connection on quit command
            socket.end(`${username} has left the chat.`);
        } else if (line.startsWith('/pm')) {
            // Handle the private message command
            socket.write(line);
        } else {
            // For normal messages, just send the line entered
            socket.write(line);
        }
    });

    // Handle incoming messages from the server
    socket.on('data', data => {
        // Display the incoming message
        console.log('\x1b[33m%s\x1b[0m', data.toString().trim());

        // If the server says you are the coordinator, you could set a flag here
        // or perform coordinator-specific actions.
        if (data.toString().includes('You are the new coordinator')) {
            // Perform any coordinator-specific initializations here
            console.log('I am now the coordinator.');
        }
    });

    // Handle disconnection from the server
    socket.on('end', () => {
        console.log('Disconnected from server.');
        rl.close();
        process.exit();
    });


    socket.on('error', error => {
        console.error('Connection error:', error.message);
        rl.close();
        process.exit();
    });
});
