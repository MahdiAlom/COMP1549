const net = require('net');

let clients = [];
let coordinator = null;

function broadcast(message, sender) {
    clients.forEach(client => {
        if (client !== sender) {
            client.socket.write(message);
        }
    });
}

function electCoordinator() {
    // Elect the next available client as the coordinator
    if (clients.length > 0) {
        coordinator = clients[0];
        coordinator.socket.write('You are the new coordinator.\n');
        broadcast(`${coordinator.username} is the new coordinator.\n`, coordinator);
        console.log(`${coordinator.username} is the new coordinator.`);
    } else {
        coordinator = null;
        console.log('No clients connected, coordinator election postponed.');
    }
}

function sendPrivateMessage(sender, recipientUsername, message) {
    const recipient = clients.find(client => client.username === recipientUsername);
    if (recipient) {
        recipient.socket.write(`[PM from ${sender.username}]: ${message}\n`);
    } else {
        sender.socket.write('User not found.\n');
    }
}

const server = net.createServer(clientSocket => {
    const client = { socket: clientSocket, username: undefined };

    clientSocket.on('data', data => {
        const message = data.toString().trim();
        if (!client.username) {
            // First message should be the username
            client.username = message;
            clients.push(client);
            console.log(`A new client has connected: ${client.username}`);
            if (!coordinator) {
                coordinator = client;
                coordinator.socket.write('You are the coordinator.\n');
                console.log(`${coordinator.username} is the new coordinator.`);
            }
            return;
        }

        console.log(`Received message: ${message}`);
        if (message.startsWith('/pm')) {
            // Private message handling
            const parts = message.split(' ');
            const recipientUsername = parts[1];
            const privateMessage = parts.slice(2).join(' ');
            sendPrivateMessage(client, recipientUsername, privateMessage);
        } else {
            broadcast(`${client.username}: ${message}`, client);
        }
    });

    clientSocket.on('end', () => {
        clients = clients.filter(c => c !== client);
        console.log(`${client.username} has disconnected.`);
        // If the disconnected client was the coordinator, elect a new one
        if (client === coordinator) {
            electCoordinator();
        }
    });

    clientSocket.on('error', error => {
        console.error(`Connection error for ${client.username}: ${error}`);
        clientSocket.end(); // Ensure the socket is closed properly
        clients = clients.filter(c => c !== client);
        // Elect new coordinator if the disconnected client was the coordinator
        if (client === coordinator) {
            electCoordinator();
        }
    });
});

server.listen(1235, () => {
    console.log('Server listening on port 1235');
});
